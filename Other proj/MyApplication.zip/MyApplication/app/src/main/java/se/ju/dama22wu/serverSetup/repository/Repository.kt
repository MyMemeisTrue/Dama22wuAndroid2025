package se.ju.dama22wu.serverSetup.repository

import se.ju.dama22wu.serverSetup.api.RetrofitInstance
import se.ju.dama22wu.serverSetup.model.Post

class Repository {
    suspend fun getPost(): Post {
        return RetrofitInstance.api.getPost()
    }
}