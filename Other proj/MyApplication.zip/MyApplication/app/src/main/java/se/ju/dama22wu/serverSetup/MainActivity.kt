package se.ju.dama22wu.serverSetup

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import se.ju.dama22wu.serverSetup.repository.Repository
import se.ju.dama22wu.serverSetup.ui.theme.MyApplicationTheme



class MainActivity : ComponentActivity() {
    private lateinit var viewModel : MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val repository = Repository()
        val viewModelFactory = MainViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory)[MainViewModel::class.java]
        viewModel.getPost()
        viewModel.myResponse.observe(this, Observer { response ->
            if(response != null){
                Log.d("Response", response.body)
                Log.d("Response", response.myUserid.toString())
                Log.d("Response", response.id.toString())
                Log.d("Response", response.title)
            } else {
                Log.e("Response", "Response is null")
            }

        })

    }
}

