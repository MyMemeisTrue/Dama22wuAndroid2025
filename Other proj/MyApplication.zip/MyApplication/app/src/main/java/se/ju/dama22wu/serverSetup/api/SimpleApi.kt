package se.ju.dama22wu.serverSetup.api

import retrofit2.http.GET
import se.ju.dama22wu.serverSetup.model.Post

interface SimpleApi {
    @GET("posts/1")
    suspend fun getPost(): Post
}