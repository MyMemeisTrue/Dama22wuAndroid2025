package se.ju.dama22wu.serverSetup.model

import com.google.gson.annotations.SerializedName

data class Post(
    @SerializedName("userId")
    val myUserid: Int,
    val id: Int,
    val title: String,
    val body: String,
)
