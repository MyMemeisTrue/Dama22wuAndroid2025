package se.ju.dama22wu.serverSetup.util

class Constants {
    companion object{
        const val BASE_URL = "https://jsonplaceholder.typicode.com"
    }
}